#!/usr/bin/env python3
from aws_cdk import (
    aws_ecr as ecr,
    aws_eks as eks,
    aws_ec2 as ec2,
    aws_iam as iam,
    core
)
import boto3 

class Kubernetes(core.Stack):

  def __init__(self, scope: core.Construct, id: str, VPC: ec2.Vpc, **kwargs) -> None:
    super().__init__(scope, id, **kwargs)

    cluster_admin = iam.Role(self, "AdminRole",
      assumed_by=iam.AccountRootPrincipal()
    )

    self.cluster = eks.Cluster(
      self, 
      "cluster",
      default_capacity=self.node.try_get_context("kubernetes")["default_capacity"],
      default_capacity_instance=ec2.InstanceType(self.node.try_get_context("kubernetes")["default_capacity_instance"]),
      cluster_name="statement-demo",
      vpc=VPC,
      vpc_subnets = VPC.private_subnets,
      masters_role=cluster_admin,
      version=eks.KubernetesVersion.V1_17,
      endpoint_access=eks.EndpointAccess.PRIVATE
    )

    vpc_security_group=ec2.SecurityGroup.from_security_group_id(self, "sgVPC", VPC.vpc_default_security_group)
    eks_security_group=ec2.SecurityGroup.from_security_group_id(self, "sgEKS", self.cluster.cluster_security_group_id)

    vpc_security_group.add_ingress_rule(
      eks_security_group,
      ec2.Port.all_traffic()
    )

    eks_security_group.add_ingress_rule(
      vpc_security_group,
      ec2.Port.all_traffic()
    )

    self.cluster.default_nodegroup.role.add_managed_policy(
      iam.ManagedPolicy.from_aws_managed_policy_name("CloudWatchAgentServerPolicy")
    )


    #see https://github.com/kubernetes/kubernetes/issues/61486?#issuecomment-635169272
    eks.KubernetesPatch(
      self,
      "patch",
      cluster=self.cluster,
      resource_name="daemonset/kube-proxy",
      resource_namespace="kube-system",
      apply_patch = {
        "spec": {
          "template": {
            "spec": {
              "containers": [{
                "name": "kube-proxy",
                "command": [
                    "kube-proxy",
                    "--v=2",
                    "--hostname-override=$(NODE_NAME)",
                    "--config=/var/lib/kube-proxy-config/config",
                ],
                "env": [{
                  "name": "NODE_NAME",
                  "valueFrom": {
                    "fieldRef": {
                      "apiVersion": "v1",
                      "fieldPath": "spec.nodeName"
                    }
                  }
                }]
              }]
            }
          }
        }
      },
      restore_patch={
        "spec": {
          "template": {
            "spec": {
              "containers": [{
                "name": "kube-proxy",
                "command": [
                  "kube-proxy",
                  "--v=2",
                  "--config=/var/lib/kube-proxy-config/config"
                ]
              }]
            }
          }
        }
      }
    )
    
    self.cluster.aws_auth.add_user_mapping(
      iam.User.from_user_name(
        self, "me",
        boto3.client('sts').get_caller_identity().get('Arn').partition('/')[2]
      ), 
      groups=["system:masters"]
    )

    loadGenerateRepository = ecr.Repository(
      self, "loadgenerate",
      removal_policy=core.RemovalPolicy.DESTROY,
      repository_name="load-generate",
      lifecycle_rules=[ecr.LifecycleRule(max_image_count=1)]
    )

    loadRepository = ecr.Repository(
      self, "load",
      removal_policy=core.RemovalPolicy.DESTROY,
      repository_name="load",
      lifecycle_rules=[ecr.LifecycleRule(max_image_count=1)]
    )

    dataIngestionRepository = ecr.Repository(
      self, "dataingestion",
      removal_policy=core.RemovalPolicy.DESTROY,
      repository_name="data-ingestion",
      lifecycle_rules=[ecr.LifecycleRule(max_image_count=1)]
    )

    jmeterRepository = ecr.Repository(
      self, "jmeter",
      removal_policy=core.RemovalPolicy.DESTROY,
      repository_name="jmeter",
      lifecycle_rules=[ecr.LifecycleRule(max_image_count=1)]
    )

    core.CfnOutput(
      self, "loadRepository",
      value=loadRepository.repository_uri
    )

    core.CfnOutput(
      self, "loadGenerateRepository",
      value=loadGenerateRepository.repository_uri
    )

    core.CfnOutput(
      self, "dataIngestionRepository",
      value=dataIngestionRepository.repository_uri
    )