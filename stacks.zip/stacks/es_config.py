#!/usr/bin/env python3
import boto3
from aws_cdk import (
		aws_ec2 as ec2,
		aws_elasticsearch as es,
		custom_resources as sdk,
		core
)
acm = boto3.client('acm')

class ElastiSearchConfig(core.Stack):
	def __init__(self, scope: core.Construct, id: str, domain: es.CfnDomain, **kwargs) -> None:
		print ("Do nothing.")
