#!/usr/bin/env python3
from aws_cdk import (
		aws_eks as eks,
		aws_iam as iam,
		core
)

class EKSIAMRoles(core.Stack):

	def __init__(self, scope: core.Construct, id: str, cluster: eks.Cluster, **kwargs) -> None:
		super().__init__(scope, id, **kwargs)

		oidc_provider = core.Fn.select(1, core.Fn.split("://", cluster.cluster_open_id_connect_issuer_url))
		account = core.Stack.of(self).account
		role = iam.Role(
			self, "role",
			assumed_by=iam.FederatedPrincipal(
				"arn:aws:iam::%s:oidc-provider/%s" % (account, oidc_provider),
				{"StringEquals":
					core.CfnJson(
						self,
						"ConditionJson",
						value={
							("%s:sub" % oidc_provider) : "system:serviceaccount:default:statement-demo"
						}
					)
				}
			)
		)

		iam.Policy(
			self, "saPolicy", 
			force=True, 
			policy_name="EKSSAPolicy", 
			roles=[role], 
			statements=[
				iam.PolicyStatement(
					actions=["cloudwatch:PutMetricData"], 
					conditions={
						"StringEquals": {
							"cloudwatch:namespace": "statement12"
						},
					},
					resources=["*"]
				)
			]
		)

		manifest = {
			"apiVersion": "v1",
			"kind": "ServiceAccount",
			"metadata": {
				"name": "statement-demo",
				"annotations" : {
					"eks.amazonaws.com/role-arn": ("arn:aws:iam::%s:role/%s" % (core.Stack.of(self).account,role.role_name))
				}
			}
		}

		eks.KubernetesManifest(
			self, 
			"serviceAccount", 
			cluster=cluster, 
			manifest=[manifest]
		)    

		core.CfnOutput(
			self, "roleName",
			value=role.role_name
		)