#!/usr/bin/env python3
from aws_cdk import (
    aws_ec2 as ec2,
    aws_iam as iam,
    aws_elasticsearch as es,
    aws_logs as logs,
    custom_resources as sdk,
    core
)
import json

class Elastic(core.Stack):
  def __init__(self, scope: core.Construct, id: str, VPC: ec2.Vpc, **kwargs) -> None:
    super().__init__(scope, id, **kwargs)
    # elastic policy
    elastic_policy = iam.PolicyStatement(
        effect=iam.Effect.ALLOW, actions=["es:*",], resources=["*"],
    )
    elastic_policy.add_any_principal()
    elastic_document = iam.PolicyDocument()
    elastic_document.add_statements(elastic_policy)

    appLog=logs.LogGroup(
      self, "appLog",
      log_group_name="/statement-demo/es/app",
      removal_policy=core.RemovalPolicy.DESTROY, 
      retention=logs.RetentionDays.ONE_WEEK
    )

    searchLog=logs.LogGroup(
      self, "searchLog",
      log_group_name="/statement-demo/es/search",
      removal_policy=core.RemovalPolicy.DESTROY, 
      retention=logs.RetentionDays.ONE_WEEK
    )

    indexLog=logs.LogGroup(
      self, "indexLog",
      log_group_name="/statement-demo/es/index",
      removal_policy=core.RemovalPolicy.DESTROY, 
      retention=logs.RetentionDays.ONE_WEEK
    )

    auditLog=logs.LogGroup(
      self, "auditLog",
      log_group_name="/statement-demo/es/audit",
      removal_policy=core.RemovalPolicy.DESTROY, 
      retention=logs.RetentionDays.ONE_WEEK
    )

    # esRole = iam.Role(
    #   self,
    #   "esLogRole",
    #   assumed_by=iam.ServicePrincipal(
    #       "es.amazonaws.com"
    #   ),
    #   inline_policies=[
    #     iam.PolicyDocument(
    #       statements=[
    #         iam.PolicyStatement(
    #           actions=[
    #             "logs:PutLogEvents",
    #             "logs:CreateLogStream"
    #           ],
    #           resources=[
    #             "arn:aws:logs:%s:%s:log-group:statement-demo/es/app:*" % (core.Stack.of(self).region, core.Stack.of(self).region),
    #             "arn:aws:logs:%s:%s:log-group:statement-demo/es/search:*" % (core.Stack.of(self).region, core.Stack.of(self).region),
    #             "arn:aws:logs:%s:%s:log-group:statement-demo/es/index:*" % (core.Stack.of(self).region, core.Stack.of(self).region),
    #             "arn:aws:logs:%s:%s:log-group:statement-demo/es/audit:*" % (core.Stack.of(self).region, core.Stack.of(self).region)
    #           ]
    #         )
    #       ]
    #     )

    #   ]
    # )

    # esPrincipal = 

    # esPrincipal.add_to_policy(
    # )

    # iam.Policy(
    #   self,
    #   "esLogPolicy",
    #   statements=[
    #     iam.PolicyStatement(
    #       actions=[
    #         "logs:PutLogEvents",
    #         "logs:CreateLogStream"
    #       ],
    #       principals=[
    #       ],
    #       resources=[
    #         "arn:aws:logs:%s:%s:log-group:statement-demo/es/app:*" % (core.Stack.of(self).region, core.Stack.of(self).region),
    #         "arn:aws:logs:%s:%s:log-group:statement-demo/es/search:*" % (core.Stack.of(self).region, core.Stack.of(self).region),
    #         "arn:aws:logs:%s:%s:log-group:statement-demo/es/index:*" % (core.Stack.of(self).region, core.Stack.of(self).region),
    #         "arn:aws:logs:%s:%s:log-group:statement-demo/es/audit:*" % (core.Stack.of(self).region, core.Stack.of(self).region)
    #       ]
    #     )
    #   ],

    # )

# {
#   "Version": "2012-10-17",
#   "Statement": [
#     {
#       "Effect": "Allow",
#       "Principal": {
#         "Service": "es.amazonaws.com"
#       },
#       "Action": [
#         "logs:PutLogEvents",
#         "logs:CreateLogStream"
#       ],
#       "Resource": "arn:aws:logs:us-east-1:837108680928:log-group:/aws/aes/domains/statement-demo/audit-logs:*"
#     }
#   ]
# }

    # TODO: Migrate this from cfn to domain when it's stable
    self.domain = es.Domain(
      self,
      "elastic_domain",
      version=es.ElasticsearchVersion.V7_7, 
      access_policies=[elastic_policy],
      advanced_options=None, 
      capacity=es.CapacityConfig(
        data_node_instance_type=self.node.try_get_context("elastic")['instanceType'], 
        data_nodes=self.node.try_get_context("elastic")['instanceCount'], 
        master_node_instance_type=self.node.try_get_context("elastic")['dedicatedMasterType'], 
        master_nodes=self.node.try_get_context("elastic")['dedicatedMasterCount']
      ), 
      domain_name="statement-demo", 
      ebs=es.EbsOptions(enabled=(not self.node.try_get_context("elastic")['instanceType'].startswith("i3"))), 
      encryption_at_rest=es.EncryptionAtRestOptions(enabled=True),
      enforce_https=True, 
      logging=es.LoggingOptions(
        app_log_enabled=True, 
        app_log_group=appLog, 
        slow_index_log_enabled=True, 
        slow_index_log_group=indexLog, 
        slow_search_log_enabled=True, 
        slow_search_log_group=searchLog
      ), 
      node_to_node_encryption=True, 
      tls_security_policy=es.TLSSecurityPolicy.TLS_1_2, 
      use_unsigned_basic_auth=True, 
      vpc_options=es.VpcOptions(
        security_groups=[],
        subnets=VPC.private_subnets
      ), 
      zone_awareness=es.ZoneAwarenessConfig(
        availability_zone_count=3, 
        enabled=True
      )
    )
    core.CfnOutput(
      self,
      "elasticsearchEndpoint",
      value=self.domain.domain_endpoint
    )
    core.CfnOutput(
      self,
      "elasticsearchPassword",
      value=self.domain.master_user_password.to_string()
    )
    # arn = sdk.AwsCustomResource(
    #   self, 'esLogPolicy',
    #   policy=sdk.AwsCustomResourcePolicy.from_sdk_calls(resources=["*"]), 
    #   on_create=sdk.AwsSdkCall(
    #     action='putResourcePolicy', 
    #     service='CloudWatchLogs', 
    #     physical_resource_id=sdk.PhysicalResourceId.of("updateElasticsearchDomainConfig"), 
    #     output_path="DomainConfig.ElasticsearchClusterConfig",
    #     parameters={
    #       "policyName": 'esLogPolicy',
    #       "policyDocument": json.dumps({
    #         "Version": "2012-10-17",
    #         "Statement": [
    #           {
    #             "Sid": 'esLogPolicy',
    #             "Effect": "Allow",
    #             "Principal": {
    #               "Service": ["es.amazonaws.com"],
    #             },
    #             "Action": ["logs:CreateLogStream", "logs:PutLogEvents","logs:PutLogEventsBatch"],
    #             "Resource": "arn:aws:logs:%s:%s:log-group:/statement-demo/es/*:*" % (core.Stack.of(self).region, core.Stack.of(self).region)
    #           },
    #         ],
    #       })
    #     }
    #   ),
    # )
    # searchLog.node.add_dependency(arn)


    # self.domain = es.CfnDomain(
    #   self,
    #   "elastic_domain",
    #   access_policies=elastic_document,
    #   advanced_security_options={
    #     "enabled" : True,
    #     "internalUserDatabaseEnabled" : True,
    #     "masterUserOptions" : {
    #       "masterUserName" : "statement",
    #       "masterUserPassword" : "Statement-1"
    #     }
    #   },
    #   domain_endpoint_options={
    #     "enforceHttps" : True,
    #     "tlsSecurityPolicy" : "Policy-Min-TLS-1-2-2019-07"
    #   },
    #   domain_name="statement-demo",
    #   elasticsearch_cluster_config={
    #     "instanceCount": self.node.try_get_context("elastic")['instanceCount'],
    #     "instanceType": self.node.try_get_context("elastic")['instanceType'],
    #     "zoneAwarenessEnabled": True,
    #     "zoneAwarenessConfig": {"availabilityZoneCount": 3},
    #     "dedicatedMasterEnabled": True,
    #     "dedicatedMasterType": self.node.try_get_context("elastic")['dedicatedMasterType'],
    #     "dedicatedMasterCount": self.node.try_get_context("elastic")['dedicatedMasterCount'],
    #   },
    #   elasticsearch_version="7.7",
    #   encryption_at_rest_options={
    #     "enabled" : True
    #   },
    #   node_to_node_encryption_options={
    #     "enabled" : True
    #   },
    #   vpc_options={
    #       "subnetIds": [subnet.subnet_id for subnet in VPC.private_subnets],
    #   },
      # log_publishing_options={
      #   "SEARCH_SLOW_LOGS": es.CfnDomain.LogPublishingOptionProperty(
      #     cloud_watch_logs_log_group_arn=searchLog.log_group_arn,
      #     enabled=True
      #   ),

      #   "ES_APPLICATION_LOGS": es.CfnDomain.LogPublishingOptionProperty(
      #     cloud_watch_logs_log_group_arn=appLog.log_group_arn,
      #     enabled=True
      #   ),

      #   "INDEX_SLOW_LOGS": es.CfnDomain.LogPublishingOptionProperty(
      #     cloud_watch_logs_log_group_arn=indexLog.log_group_arn,
      #     enabled=True
      #   ),

      #   "AUDIT_LOGS": es.CfnDomain.LogPublishingOptionProperty(
      #     cloud_watch_logs_log_group_arn=auditLog.log_group_arn,
      #     enabled=True
      #   ),
      # }
    # )
    # self.domain.node.add_dependency(auditLog)
    # self.domain.node.add_dependency(searchLog)
    # self.domain.node.add_dependency(indexLog)
    # self.domain.node.add_dependency(appLog)


    # self.domain.node.add_dependency(
    #   searchLog.grant_write(iam.ServicePrincipal("es.amazonaws.com"))  
    # )
    # .apply_before(self.domain)

    # self.domain.node.add_dependency(arn)


    # for group in [appLog, searchLog, indexLog, auditLog]:
    #   policyName = 'esLogPolicy-%s' % group.log_group_name
      # arn.node.add_dependency(group)

    # core.CfnOutput(
    #   self,
    #   "elasticsearchEndpoint",
    #   value=self.domain.attr_domain_endpoint
    # )
