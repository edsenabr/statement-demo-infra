#!/usr/bin/env python3
from aws_cdk import (
		aws_eks as eks,
		aws_elasticsearch as es,
		aws_msk as msk,
		custom_resources as sdk,
		core
)
import boto3 
client = boto3.client('kafka')


class ServiceDiscovery(core.Stack):

	def __init__(self, scope: core.Construct, id: str, cluster: eks.Cluster, domain: es.CfnDomain, kafka: msk.CfnCluster,**kwargs) -> None:
		super().__init__(scope, id, **kwargs)

		arn = sdk.AwsCustomResource(
			self, 'clusterArn',
			policy=sdk.AwsCustomResourcePolicy.from_sdk_calls(resources=['*']), 
			on_create=sdk.AwsSdkCall(
				action='listClusters', 
				service='Kafka', 
				physical_resource_id=sdk.PhysicalResourceId.of("ClusterNameFilter"), 
				parameters={
					"ClusterNameFilter": kafka.cluster_name,
					"MaxResults": 1
				}, 
			), 
		)

		bootstraps = sdk.AwsCustomResource(
			self, 'clusterBootstraps',
			policy=sdk.AwsCustomResourcePolicy.from_sdk_calls(resources=["*"]),
			on_create=sdk.AwsSdkCall(
				action='getBootstrapBrokers', 
				service='Kafka', 
				physical_resource_id=sdk.PhysicalResourceId.of("ClusterArn"), 
				parameters={
					"ClusterArn": arn.get_response_field("ClusterInfoList.0.ClusterArn")
				},
			), 
		)

		for namespace in ['load-generate', 'load', 'data-ingestion', 'jmeter']:
			ns = eks.KubernetesManifest(
				self, 
				"namespace-%s" % namespace, 
				cluster=cluster, 
				manifest=[{
					"apiVersion": "v1",
					"kind": "Namespace",
					"metadata": {
						"name": namespace
					},
				}]
			)

			eks.KubernetesManifest(
				self, 
				"service-discovery-%s" % namespace, 
				cluster=cluster,
				manifest=[{
					"apiVersion": "v1",
					"kind": "ConfigMap",
					"metadata": {
						"name": "service-discovery",
						"namespace": namespace
					},
					"data": {
						"msk":  bootstraps.get_response_field('BootstrapBrokerStringTls'),
						"es": domain.attr_domain_endpoint
					}
				}]
			).node.add_dependency(ns)

# apiVersion: v1
# kind: Namespace
# metadata:
#   name: amazon-cloudwatch
#   labels:
#     name: amazon-cloudwatch

		# manifest = {
		# 	"apiVersion": "v1",
		# 	"kind": "ConfigMap",
		# 	"metadata": {
		# 		"name": "service-discovery",
		# 		"namespace": "load-generate"
		# 	},
		# 	"data": {
		# 		"msk":  bootstraps.get_response_field('BootstrapBrokerStringTls'),
		# 		"es": domain.attr_domain_endpoint
		# 	}
		# }

		# eks.KubernetesManifest(
		# 	self, 
		# 	"service-discovery", 
		# 	cluster=cluster, 
		# 	manifest=[manifest]
		# )